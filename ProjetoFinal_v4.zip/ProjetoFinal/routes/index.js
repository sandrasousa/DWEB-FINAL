var express = require('express');
var router = express.Router();
var passport = require('passport')
var axios = require('axios')

/* GET home page. */
router.get('/', function(req, res) {
  axios.get('http://localhost:4005/api/pubs')
    .then(resposta => res.render('index', { pubs: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('erro', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
});

/* Login
router.get('/login', (req,res) => {
  console.log('Na cb do GET /login ... : ' + req.sessionID)
  res.render('login')
})

router.post('/login', passport.authenticate('local', {
  successRedirect: '/pubs',
  failureRedirect: '/login'
}))

// Proteger com middleware
function verificaAutenticacao(req, res, next){
  if(req.isAuthenticated()) next()
  else res.redirect("/login")
}

router.get('/users', verificaAutenticacao, (req,res) => {
  axios.get('http://localhost:4005/users')
    .then(dados => res.render('users', {usersList: dados.data}))
    .catch(erro => res.render('error', {error: erro}))
}) */

/* GET /pubs */
router.get('/pubs', (req, res) => {
  axios.get('http://localhost:4005/api/pubs')
    .then(resposta => res.render('feed', { pubs: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('erro', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
});

/* GET /pubs/nova */
router.get('/pubs/nova', (req, res) => {
  axios.get('http://localhost:4005/api/pubs/nova')
    .then(resposta => res.render('nova', { pub: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('error', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
});

/* GET /pubs/foto */
router.get('/pubs/foto', (req, res) => {
  axios.get('http://localhost:4005/api/pubs/foto')
    .then(resposta => res.render('foto', { pub: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('error', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
});

/* GET /pubs/local */
router.get('/pubs/local', (req, res) => {
  axios.get('http://localhost:4005/api/pubs/local')
    .then(resposta => res.render('local', { pub: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('error', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
});

/* GET /pubs/:pid */
router.get('/pubs/:pid', (req, res) =>  {
  axios.get('http://localhost:4005/api/pubs/' + req.params.pid)
    .then(resposta => res.render('pub', { pub: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('error', {error: erro, message: 'Erro ao carregar evento da Base de Dados'})
    })
});

/* GET /pubs/tipo/:t */
router.get('/pubs/tipo/:t', (req, res) =>  {
  axios.get('http://localhost:4005/api/pubs/tipo/' + req.params.t)
    .then(resposta => res.render('pub-tipo', { pubs: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('error', {error: erro, message: 'Erro ao carregar tipo de publicação da Base de Dados'})
    })
});

/* POST /pubs */
router.post('/pubs', (req, res) =>  {
  axios.post('http://localhost:4005/api/pubs', req.body)
    .then(() => res.redirect('http://localhost:4005/pubs'))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.redirect('http://localhost:4005/')
    })
});

/* DELETE /pubs/:pid 
router.delete('/pubs/apagar/', function(req, res) {
  axios.delete('http://localhost:4005/api/pubs/' + req.params.pid)
    .then(() => res.redirect('http://localhost:4005/'))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.redirect('http://localhost:4005/')
    })
});*/

/* UPDATE /pubs
router.post('/pubs/comentar/', function(req, res) {
  axios.post('http://localhost:4005/api/pubs/comentar/' + req.params.pid)
    .then(resposta => res.render('pub', { pub: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.redirect('http://localhost:4005/')
    })
});*/ 

module.exports = router;
