var mongoose = require('mongoose')
/*modulo para encriptar a pass
var bcrypt = require('bcrypt')*/
var Schema = mongoose.Schema

var PubSchema = require('./api/pub')

var UserSchema = new Schema({
    email: {
        type: String,
        require: true,
        unique: true
    },
    password: {
        type: String,
        require: true
    },
    //pub: PubSchema 
})

//pré-ação - primeiro encripta a password
UserSchema.pre('save', async function(next) {
                                                //tempo da escrita na bd
    var hash = await bcrypt.hash(this.password, 10)
    this.password = hash
    next()
})

///metodo de validação da password que foi escrita e a da bd
UserSchema.methods.isValidPassword = async function(password){
    var user = this
    var compare = await bcrypt.compare(password, user.password)
    return compare
}
                              //ele vai procurar uma ligação na bd chamada users
var UserModel = mongoose.model('user', UserSchema)

module.exports = UserModel