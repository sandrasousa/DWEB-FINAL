var d = new Date();
document.getElementById("myDate").innerHTML = d;