var mongoose = require('mongoose')
var Schema = mongoose.Schema

var PubSchema = new Schema({
    estado: {type: String}, // privado (por defeito) ou público
    nome: {type: String}, // nome da publicação
    local: {type: String}, // localização da publicação (opcional)
    descricao: {type: String}, // descrição da publicação (opcional)
    dataInicio: {type: String}, // data de inicio (por defeito a presente data)
    dataFim: {type: String}, // data do fim da publicação (opcional)
    tipo: {type: String}, // tipo de publicação (desportivo, cultural, culinária)
    anexo: {type: String}, // anexos: fotos, videos (opcional)
    nota: {type: String} // correspondem aos comentários
})

module.exports = mongoose.model('Pub', PubSchema, 'pubs')

