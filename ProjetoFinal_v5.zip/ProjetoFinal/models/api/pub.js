var mongoose = require('mongoose')
var Schema = mongoose.Schema
const User = require('../user')

var PubSchema = new Schema({
    content:{
    estado: {type: String}, // privado (por defeito) ou público
    nome: {type: String}, // nome da publicação
    local: {type: String}, // localização da publicação (opcional)
    descricao: {type: String}, // descrição da publicação (opcional)
    dataInicio: {type: String}, // data de inicio (por defeito a presente data)
    dataFim: {type: String}, // data do fim da publicação (opcional)
    tipo: {type: String}, // tipo de publicação (desportivo, cultural, culinária)
    anexo: {data: Buffer, contentType: String}, // anexos: fotos, videos (opcional)
    notas: {type: String}, //imgSchema  // correspondem aos comentários
    likes_count: {type: Number}
    },
    user:{
        type: Schema.Types.ObjectId,
        ref: 'User'
    }
})

module.exports = mongoose.model('Pub', PubSchema, 'pubs')

