var express = require('express')
var router = express.Router()
var Pub = require('../../controllers/api/pub')

/* GET /api/pubs */
    //para obter a lista de publicações
router.get('/', (req,res)=>{
    Pub.listar()
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na listagem das publicações'))
})

/* GET /api/pubs/nova */
    //para obter a lista de novas publicações
router.get('/nova', (req,res)=>{
    Pub.listar()
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na listagem das publicações'))
})

/* GET /api/pubs/foto */
    //para obter a lista de novas fotos
    router.get('/foto', (req,res)=>{
        Pub.listar()
            .then(dados => res.json(dados))
            .catch(erro => res.status(500).send('Erro na listagem das publicações'))
    })

/* GET /api/pubs/local */
    //para obter a lista de novos locais
router.get('/local', (req,res)=>{
    Pub.listar()
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na listagem das publicações'))
})

/* GET /api/pub/:pid */ 
    //para obter publicações por id
router.get('/:pid', (req,res)=>{
    Pub.consultar(req.params.pid)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na consulta da publicação.'))
})

/* GET /api/pub/tipo/:t */ 
    //para obter publicações por tipo
router.get('/tipo/:t', (req,res)=>{
    Pub.listarTipo(req.params.t)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na listagem por tipo de publicações.'))
})

/* POST api/pubs */ 
    //para criar novas publicação/fotos/locais
router.post('/', (req,res)=>{
    Pub.inserir(req.body)
    .then(dados => res.json(dados))
    .catch(erro => res.status(500).send('Erro na inserção da publicação.'))
})

/* POST api/pubs/nova */ 
    //para criar nova publicação
    router.post('/nova', (req,res)=>{
        Pub.inserir(req.body)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na inserção da publicação.'))
    })

/* POST api/pubs/foto */ 
    //para criar nova foto
    router.post('/foto', (req,res)=>{
        Pub.inserir(req.body)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na inserção da publicação.'))
    })

/* POST api/pubs/local */ 
    //para criar novo locais
    router.post('/local', (req,res)=>{
        Pub.inserir(req.body)
        .then(dados => res.json(dados))
        .catch(erro => res.status(500).send('Erro na inserção da publicação.'))
    })

module.exports = router;