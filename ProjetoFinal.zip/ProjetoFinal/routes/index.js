var express = require('express');
var router = express.Router();
var axios = require('axios');

/* GET home page. */
router.get('/', function(req, res) {
  axios.get('http://localhost:4005/api/pubs')
    .then(resposta => res.render('index', { pubs: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('erro', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
});

/* GET /pubs */
router.get('/pubs', function(req, res) {
  axios.get('http://localhost:4005/api/pubs')
    .then(resposta => res.render('pub', { pub: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('erro', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
});

/* GET /pubs/nova */
router.get('/pubs/nova', function(req, res) {
  axios.get('http://localhost:4005/api/pubs/nova')
    .then(resposta => res.render('nova', { pub: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('erro', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
});

/* GET /pubs/foto */
router.get('/pubs/foto', function(req, res) {
  axios.get('http://localhost:4005/api/pubs/foto')
    .then(resposta => res.render('foto', { pub: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('erro', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
});

/* GET /pubs/local */
router.get('/pubs/local', function(req, res) {
  axios.get('http://localhost:4005/api/pubs/foto')
    .then(resposta => res.render('local', { pub: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('erro', {error: erro, message: 'Erro ao carregar dados da BD'})
    })
});

/* GET /pubs/:pid */
router.get('/pubs/:pid', function(req, res) {
  axios.get('http://localhost:4005/api/pubs/' + req.params.pid)
    .then(resposta => res.render('pub', { pub: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('erro', {error: erro, message: 'Erro ao carregar evento da BD'})
    })
});

/* POST /pubs */
router.post('/', function(req, res) {
  axios.post('http://localhost:4005/api/pubs', req.body)
    .then(() => res.redirect('http://localhost:4005/'))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.redirect('http://localhost:4005/')
    })
});

/* POST /pubs/nova */
router.post('/nova', function(req, res) {
  axios.post('http://localhost:4005/api/pubs/nova')
    .then(() => res.redirect('http://localhost:4005/'))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.redirect('http://localhost:4005/')
    })
});

/* POST /pubs/foto */
router.post('/foto', function(req, res) {
  axios.post('http://localhost:4005/api/pubs/foto')
    .then(() => res.redirect('http://localhost:4005/'))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.redirect('http://localhost:4005/')
    })
});


/* POST /pubs/local */
router.post('/local', function(req, res) {
  axios.post('http://localhost:4005/api/pubs/local')
    .then(() => res.redirect('http://localhost:4005/'))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.redirect('http://localhost:4005/')
    })
});


module.exports = router;
