var Pub = require('../../models/api/pub')

// GET /api/pub - listar publicações
module.exports.listar = () => {
    return Pub
        .find()
        .sort({data: -1})
        .exec()
}

//GET /api/pub/:pid - consultar publicações por id
module.exports.consultar = (pid) => {
    return Pub
        .findOne({_id: pid})
        .exec()
}

// GET /api/pub/data/:d - listar publicações por data
module.exports.listarData = data => {
    return Pub
        .find({data: {$gte: data}})
        .sort({data: -1})
        .exec()
}

// GET /api/pub/tipo/:t - listar publicações por tipo de evento
module.exports.listarTipo = tipo => {
    return Pub
        .find({tipo: tipo})
        .sort({data: -1})
        .exec()
}