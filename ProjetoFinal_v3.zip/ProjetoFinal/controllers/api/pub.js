var Pub = require('../../models/api/pub')

// GET /api/pub - listar publicações
module.exports.listar = () => {
    return Pub
        .find()
        .sort({data: -1})
        .exec()
}

//GET /api/pub/:pid - consultar publicações por id
module.exports.consultar = (pid) => {
    return Pub
        .findOne({_id: pid})
        .exec()
}

// GET /api/pub/data/:d - listar publicações por data
module.exports.listarData = data => {
    return Pub
        .find({data: {$gte: data}})
        .sort({data: -1})
        .exec()
}

// GET /api/pub/tipo/:t - listar publicações por tipo de evento
module.exports.listarTipo = tipo => {
    return Pub
        .find({tipo: tipo})
        .sort({data: -1})
        .exec()
}

// GET /api/pub/tipo/:t - listar publicações por tipo de evento
module.exports.listarNotas = notas => {
    return Pub
        .find({_id: ObjectId})
        //.sort({data: -1})
        .exec()
}

// POST /api/pubs
module.exports.inserir = pub => {
    return Pub.create(pub)
}

/* Delete /api/pubs
module.exports.apagar = (pid) => {
    return Pub
        .findOneAndRemove({_id: pid})
}*/

/* UPDATE /api/pubs
module.exports.comentar = pub => {
    return Pub
        .findOne({_id: pid})
        .insertMany({notas})
} */